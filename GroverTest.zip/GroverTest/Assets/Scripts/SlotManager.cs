﻿using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using UnityEngine.UI;

public class SlotManager : MonoBehaviour
{
    [SerializeField]
    private Text DenoText, BalanceText, WinningsText, MessageText;

    [SerializeField]
    private Button Play, Increase, Decrease;

    [SerializeField]
    private Button[] Chests = new Button[9];

    private Stack<float> WinningsStack;
    private float Deno = 0.25f, Balance = 10.0f, Winnings = 0.0f;
    private int DenoPosition = 1;

    private void Awake()
    {
        WinningsStack = new Stack<float>();
        foreach (Button button in Chests)
        {
            button.interactable = false;
        }
    }

    private void Update()
    {
        UpdateUI();
        if (Deno > Balance)
        {
            Play.interactable = false;
        }
        else
        {
            Play.interactable = true;
        }
    }

    private void UpdateUI()
    {
        DenoText.text = "Denomination: " + Deno.ToString("C", CultureInfo.CurrentCulture); ;
        BalanceText.text = "Current Balance: " + Balance.ToString("C", CultureInfo.CurrentCulture);
        WinningsText.text = "Last Game Winnings: " + Winnings.ToString("C", CultureInfo.CurrentCulture);
    }

    private void StartGame()
    {
        Balance -= Deno;
        Play.interactable = false;
        Increase.interactable = false;
        Decrease.interactable = false;
        foreach(Button button in Chests)
        {
            button.interactable = true;
        }
        QueueSetup();
    }

    private void QueueSetup()
    {
        WinningsStack.Push(0.0f);
        int ChestNumber = Random.Range(1, 8);
        int Winnings = (int)((GetModifier() * Deno) / 0.05f);
        int ChestWinning;
        Debug.Log("Winnings are " + Winnings * 0.05);
        for(int i = 0; i < ChestNumber; i++)
        {
            if(i + 1 == ChestNumber)
            {
                ChestWinning = Winnings;
            }
            else
            {
                ChestWinning = Winnings / (ChestNumber - i);
                if (ChestWinning > 5)
                    ChestWinning += Random.Range(-4, 4);
                else if (ChestWinning > 3)
                    ChestWinning += Random.Range(-2, 2);
            }
            Winnings -= ChestWinning;
            WinningsStack.Push(ChestWinning * 0.05f);
        }
        foreach(float number in WinningsStack)
        {
            Debug.Log(number);
        }
    }

    private int GetModifier()
    {
        int modifier = 0;
        int RandomNumber = Random.Range(1, 20);
        if(RandomNumber <= 10)
        {
            modifier = 0;
        }
        else if(RandomNumber > 10 && RandomNumber <= 16)
        {
            modifier = Random.Range(1, 10);
        }
        else if(RandomNumber > 16 && RandomNumber <= 19)
        {
            RandomNumber = Random.Range(1, 6);
            switch(RandomNumber)
            {
                case 1:
                    modifier = 12;
                    break;
                case 2:
                    modifier = 16;
                    break;
                case 3:
                    modifier = 24;
                    break;
                case 4:
                    modifier = 32;
                    break;
                case 5:
                    modifier = 48;
                    break;
                case 6:
                    modifier = 64;
                    break;
            }
        }
        else
        {
            RandomNumber = Random.Range(1, 5);
            modifier = RandomNumber * 100;
        }
        return modifier;
    }

    private void EndGame()
    {
        WinningsStack.Clear();
        Play.interactable = true;
        Increase.interactable = true;
        Decrease.interactable = true;
        foreach (Button button in Chests)
        {
            button.interactable = false;
        }
        Balance += Winnings;
    }

    public void ChangeDeno(bool isIncreasing)
    {
        if(isIncreasing && DenoPosition < 4)
        {
            DenoPosition++;
        }
        else if(!isIncreasing && DenoPosition > 1)
        {
            DenoPosition--;
        }
        switch(DenoPosition)
        {
            case 1:
                Deno = 0.25f;
                break;
            case 2:
                Deno = 0.5f;
                break;
            case 3:
                Deno = 1.0f;
                break;
            case 4:
                Deno = 5.0f;
                break;
        }
    }

    public void PlayButton()
    {
        MessageText.text = "";
        Winnings = 0;
        StartGame();
    }

    public void ChestOpen(Button button)
    {
        float value = WinningsStack.Pop();
        if (value == 0)
        {
            MessageText.text = "You lose!";
            EndGame();
        }

        else
        {
            MessageText.text = "You have won " + value.ToString("C", CultureInfo.CurrentCulture);
            Winnings += value;
            button.interactable = false;
        }
    }
}
